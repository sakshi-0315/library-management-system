<?php
session_start();
include "db.php";




/* ================= FETCH RETURNED ITEMS ================= */
$returnedQuery = $conn->query("
    SELECT 
        id,
        title,
        issued_to,
        issue_date,
        return_date
    FROM books
    WHERE return_date IS NOT NULL
    ORDER BY return_date DESC
");

/* ================= TOTAL RETURNED ================= */
$totalReturned = $returnedQuery->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Returned Items - Admin Panel</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
    body { font-family: "Poppins", sans-serif; background: #f5f7fa; }

    .top-header {
        width: calc(100% - 260px);
        margin-left: 260px;
        position: fixed;
        top: 0;
        left: 0;
        height: 70px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: linear-gradient(90deg, #6a11cb, #2575fc);
        padding: 0 25px;
        color: white;
        z-index: 9999;
        border-bottom: 1px solid rgba(255,255,255,0.2);
    }

    .sidebar {
        width: 260px;
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        background: #1f2833;
        color: white;
        padding-top: 90px;
        z-index: 9998;
    }

    .sidebar h3 { text-align: center; color: #66fcf1; margin-bottom: 25px; }
    .sidebar a { padding: 14px 25px; display: block; color: #c5c6c7; text-decoration: none; }
    .sidebar a:hover, .sidebar a.active { background: #45a29e; color: white; border-radius: 5px; }

    .main { margin-left: 260px; margin-top: 90px; padding: 20px 30px; }

    .stats-card {
        background: linear-gradient(135deg, #11998e, #38ef7d);
        padding: 20px;
        border-radius: 12px;
        color: white;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .search-section {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 20px;
    }

    .search-section input {
        padding: 10px 15px;
        border-radius: 8px;
        border: 1px solid #ccc;
        width: 100%;
    }

    .table-box {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
</style>
</head>

<body>

<!-- HEADER -->
<div class="top-header">
    <h1 style="font-size:22px; font-weight:700;">✔ Returned Items</h1>
    <a href="logout.php" class="btn btn-outline-light">
        <i class="fa fa-sign-out-alt"></i> Logout
    </a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="admin_dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="admin_bookpage.php"><i class="fa fa-book"></i> Books</a>
    <a href="admin_newspapers.php"><i class="fa fa-newspaper"></i> Newspapers</a>
    <a href="admin_members.php"><i class="fa fa-users"></i> Members</a>
    <a href="admin_issued.php"><i class="fa fa-arrow-right"></i> Issued</a>
    <a href="admin_notreturned.php"><i class="fa fa-times-circle"></i> Not Returned</a>
    <a href="admin_setting.php"><i class="fa fa-cog"></i> Settings</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">

    <!-- RETURNED COUNT -->
    <div class="stats-card mb-4">
        <h3>Total Returned Items</h3>
        <h1 style="font-size:45px; margin:0;"><?= $totalReturned; ?></h1>
    </div>

    <!-- SEARCH -->
    <div class="search-section">
        <input type="text" id="searchInput" placeholder="Search by member name or book/newspaper">
    </div>

    <!-- TABLE -->
    <div class="table-box">
        <h4 class="mb-3">Returned Items List</h4>

        <table class="table table-hover table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#ID</th>
                    <th>Member Name</th>
                    <th>Item Name</th>
                    <th>Type</th>
                    <th>Issued On</th>
                    <th>Returned On</th>
                </tr>
            </thead>

            <tbody>
            <?php while($row = $returnedQuery->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= htmlspecialchars($row['issued_to']); ?></td>
                    <td><?= htmlspecialchars($row['title']); ?></td>
                    <td>Book</td>
                    <td><?= $row['issue_date']; ?></td>
                    <td><?= $row['return_date']; ?></td>
                </tr>
            <?php endwhile; ?>
            </tbody>

        </table>
    </div>
</div>

<script>
const searchInput = document.getElementById("searchInput");
const rows = document.querySelectorAll("tbody tr");

searchInput.addEventListener("keyup", () => {
    const value = searchInput.value.toLowerCase();
    rows.forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(value) ? "" : "none";
    });
});
</script>

</body>
</html>
