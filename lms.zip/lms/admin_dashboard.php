<?php 
include "db.php";

$bookResult = $conn->query("SELECT COUNT(*) AS total_books FROM books");
$bookData = $bookResult->fetch_assoc();
$totalBooks = $bookData['total_books'];

$countMembers = $conn->query("SELECT COUNT(*) AS total_members FROM members");
$memberData = $countMembers->fetch_assoc();
$totalMembers = $memberData['total_members'];

$countNewspaper = $conn->query("SELECT COUNT(*) AS total_newspaper FROM newspapers");
$paperData = $countNewspaper->fetch_assoc();
$totalPaper = $paperData['total_newspaper'];

$countIssued = $conn->query("SELECT COUNT(*) AS total_issued FROM books WHERE availability_status = 'Issued'");
$issuedData = $countIssued->fetch_assoc();
$totalIssued = $issuedData['total_issued'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Library Management System</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    body {
        background: #f5f7fa;
        font-family: "Poppins", sans-serif;
    }

    /* Top Header */
    .top-header {
        width: 100%;
        height: 65px;
        background: #1f2833;
        color: white;
        display: flex;
        align-items: center;
        padding-left: 280px;
        font-size: 22px;
        font-weight: 600;
        box-shadow: 0px 3px 10px rgba(0,0,0,0.2);
    }

    /* Sidebar */
    .sidebar {
        width: 260px;
        height: 100%;
        position: fixed;
        background: #1f2833;
        color: white;
        padding-top: 30px;
        box-shadow: 2px 0 12px rgba(0,0,0,0.2);
    }
    .sidebar h3 {
        text-align: center;
        font-weight: 600;
        color: #66fcf1;
        margin-bottom: 30px;
    }
    .sidebar a {
        padding: 14px 25px;
        display: block;
        font-size: 16px;
        color: #c5c6c7;
        text-decoration: none;
    }
    .sidebar a:hover {
        background: #45a29e;
        color: white;
        border-radius: 5px;
    }

    /* Main Content */
    .main {
        margin-left: 260px;
        padding: 20px;
        margin-top: 80px;
    }

    /* Dashboard Cards */
    .dash-card {
        padding: 25px;
        border-radius: 12px;
        color: white;
        box-shadow: 0px 4px 15px rgba(0,0,0,0.15);
        transition: 0.3s;
    }
    .dash-card:hover {
        transform: translateY(-6px);
        box-shadow: 0px 8px 20px rgba(0,0,0,0.2);
    }
    .dash-icon {
        font-size: 45px;
        opacity: 0.7;
    }

    .books { background: linear-gradient(135deg, #00c6ff, #0072ff); }
    .members { background: linear-gradient(135deg, #56ab2f, #a8e063); }
    .news { background: linear-gradient(135deg, #ff9800, #ffb74d); }
    .issued { background: linear-gradient(135deg, #00bcd4, #26c6da); }
    .returned { background: linear-gradient(135deg, #e91e63, #f06292); }
    .not-returned { background: linear-gradient(135deg, #009688, #4db6ac); }
    .low-stock { background: linear-gradient(135deg, #ff4b2b, #ff416c); }

</style>
</head>

<body>

<!-- FIXED HEADER -->
<div class="top-header" style="
    position: fixed;
    top: 0; left: 0;
    height: 70px;
    width: calc(100% - 260px);
    margin-left: 260px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: linear-gradient(90deg, #6a11cb, #2575fc);
    padding: 0 25px;
    z-index: 9999;
    border-bottom: 1px solid rgba(255,255,255,0.2);
">

    <h1 style="margin:0; font-size:26px; font-weight:700; color:white;">📚 Library Management System</h1>

    
    <!-- Right: Bell + Admin -->
    <div style="display:flex; align-items:center; gap:20px; color:white;">
        <i class="fa fa-bell" style="font-size:20px;"></i>
        <div style="display:flex; align-items:center; gap:10px;">
            <span style="font-size:15px;">Admin</span>
        </div>
        <!-- Logout Button -->
        <a href="logout.php" class="btn btn-outline-light" style="border-radius:8px; padding:5px 12px; font-weight:600;">
            <i class="fa fa-sign-out-alt"></i> Logout
        </a>
    </div>
</div>

<!-- FIXED SIDEBAR (Connected to Header) -->
<div class="sidebar" style="
    position: fixed;
    top: 0;
    left: 0;
    height: 100vh;
    width: 260px;
    background: #1f2833;
    color: white;
    padding-top: 90px;
    border-right: 1px solid #0002;
    z-index: 9998;
">

    <h3 style="text-align:center; color:#66fcf1; margin-bottom:25px;">Admin Panel</h3>

    
    <a href="admin_bookpage.php"><i class="fa fa-book"></i> Books</a>
    <a href="admin_members.php"><i class="fa fa-users"></i> Members</a>
    <a href="admin_newspapers.php"><i class="fa fa-newspaper"></i> Newspapers</a>
    <a href="admin_issued.php"><i class="fa fa-arrow-right"></i> Issued</a>
    <a href="admin_returned.php"><i class="fa fa-check"></i> Returned</a>
    <a href="admin_notreturned.php"><i class="fa fa-times-circle"></i> Not Returned</a>
    <a href="admin_setting.php"><i class="fa fa-cog"></i> Settings</a>
    <a href="#"><i class="fa fa-sign-out-alt"></i>Logout </a>
</div>


<!-- MAIN CONTENT -->
<div class="main" style="
    margin-left: 260px;
    margin-top: 90px;
    padding: 20px;
    background: #f5f7fa;
">
<!-- NOTIFICATION DROPDOWN -->
<div id="notifyBox" style="
    position: fixed;
    top: 75px;
    right: 30px;
    width: 300px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    display: none;
    z-index: 999999;
">
    <ul style="list-style:none; margin:0; padding:10px;">
        <li style="padding:10px; border-bottom:1px solid #eee;">
            <span style="color:green;">📘 New Book Added:</span> Python Basics
        </li>
        <li style="padding:10px; border-bottom:1px solid #eee;">
            <span style="color:red;">⏳ Overdue:</span> Web Dev Book
        </li>
        <li style="padding:10px;">
            <span style="color:blue;">👤 New Member:</span> Rohan Patel
        </li>
    </ul>
</div>

    <!-- CARDS -->
    <div class="row">

        <div class="col-md-4 mb-4">
        <div class="dash-card books">
        <div class="d-flex justify-content-between">
            <div>
                <h3>Books</h3>
                <h2><?php echo $totalBooks; ?></h2>
            </div>
            <i class="dash-icon fa fa-book"></i>
        </div>
    </div>
</div>

        <div class="col-md-4 mb-4">
            <div class="dash-card members">
                <div class="d-flex justify-content-between">
                    <div>
                        <h3>Members</h3>
                        <h2><?php echo $totalMembers; ?></h2>
                    </div>
                    <i class="dash-icon fa fa-users"></i>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="dash-card news">
                <div class="d-flex justify-content-between">
                    <div>
                        <h3>Newspapers</h3>
                        <h2><?php echo $totalPaper; ?></h2>
                    </div>
                    <i class="dash-icon fa fa-newspaper"></i>
                </div>
            </div>
        </div>

    </div>

    <!-- CARDS ROW 2 -->
    <div class="row">

        <div class="col-md-3 mb-4">
            <div class="dash-card issued">
                <div class="d-flex justify-content-between">
                    <div>
                        <h3>Issued</h3>
                        <h2><?php echo $totalIssued; ?></h2>
                    </div>
                    <i class="dash-icon fa fa-arrow-right"></i>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="dash-card returned">
                <div class="d-flex justify-content-between">
                    <div>
                        <h3>Returned</h3>
                        <h2>1</h2>
                    </div>
                    <i class="dash-icon fa fa-check-circle"></i>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="dash-card not-returned">
                <div class="d-flex justify-content-between">
                    <div>
                        <h3>Not Returned</h3>
                        <h2>1</h2>
                    </div>
                    <i class="dash-icon fa fa-times-circle"></i>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="dash-card low-stock">
                <div class="d-flex justify-content-between">
                    <div>
                        <h3>Low Stock</h3>
                        <h2>1</h2>
                    </div>
                    <i class="dash-icon fa fa-exclamation-triangle"></i>
                </div>
            </div>
        </div>

    </div>

    <!-- LOW STOCK LIST -->
    <div class="card shadow p-3 mt-4">
        <h4 class="mb-3">Low Stock Books</h4>
        <ul>
            <li>Python Basics - 1 copy left</li>
            <li>JavaScript Essentials - 2 copies left</li>
        </ul>
    </div>

    <!-- GRAPH SECTION -->
    <h2 class="mt-5 mb-3 font-weight-bold">Analytics & Reports</h2>

    <div class="row">

        <!-- BAR CHART -->
        <div class="col-md-3 mb-4">
            <div class="card shadow p-3">
                <h4 class="text-center">Books Status</h4>
                <canvas id="booksChart" height="200"></canvas>
            </div>
        </div>

        <!-- PIE CHART -->
        <div class="col-md-3 mb-4">
            <div class="card shadow p-3">
                <h4 class="text-center">Book Categories</h4>
                <canvas id="categoryChart" height="200"></canvas>
            </div>
        </div>

        <!-- LOW STOCK CHART -->
        <div class="col-md-3 mb-4">
            <div class="card shadow p-3">
                <h4 class="text-center">Low Stock Books</h4>
                <canvas id="lowStockChart" height="200"></canvas>
            </div>
        </div>

        <!-- LINE CHART -->
        <div class="col-md-3 mb-4">
            <div class="card shadow p-3">
                <h4 class="text-center">Books Issued Trend</h4>
                <canvas id="lineChart" height="200"></canvas>
            </div>
        </div>

    </div>

</div>

<!-- GRAPH SCRIPT -->
<script>

    // BAR CHART (Issued / Returned / Not Returned)
    var ctx1 = document.getElementById('booksChart').getContext('2d');
    new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: ['Issued', 'Returned', 'Not Returned'],
            datasets: [{
                label: 'Books Count',
                data: [2, 1, 1],
                backgroundColor: ['#00bcd4', '#4caf50', '#e91e63'],
                borderRadius: 10
            }]
        },
        options: { scales: { y: { beginAtZero: true } } }
    });

    // PIE CHART (Book Categories)
    var ctx2 = document.getElementById('categoryChart').getContext('2d');
    new Chart(ctx2, {
        type: 'pie',
        data: {
            labels: ['Science', 'History', 'Technology', 'Kids', 'Comics'],
            datasets: [{
                data: [12, 8, 15, 6, 4],
                backgroundColor: ['#007bff', '#4caf50', '#ff9800', '#9c27b0', '#e91e63']
            }]
        }
    });

    // LOW STOCK CHART
    var ctx3 = document.getElementById('lowStockChart').getContext('2d');
    new Chart(ctx3, {
        type: 'bar',
        data: {
            labels: ['Python Basics', 'JavaScript Essentials'],
            datasets: [{
                label: 'Copies Left',
                data: [1, 2],
                backgroundColor: ['#ff4b2b', '#ff416c'],
                borderRadius: 10
            }]
        },
        options: { scales: { y: { beginAtZero: true } } }
    });

    // LINE CHART (Books Issued Trend)
    var ctxLine = document.getElementById('lineChart').getContext('2d');
    new Chart(ctxLine, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Books Issued',
                data: [5, 7, 3, 8, 6, 9],
                borderColor: '#0072ff',
                backgroundColor: 'rgba(0, 114, 255, 0.2)',
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#0072ff',
                pointBorderColor: '#fff',
                pointRadius: 5
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: true, position: 'top' } },
            scales: { y: { beginAtZero: true, stepSize: 1 }, x: {} }
        }
    });

</script>

<script>
let bell = document.querySelector(".fa-bell");
let notify = document.getElementById("notifyBox");

bell.addEventListener("click", function() {
    notify.style.display =
        notify.style.display === "block" ? "none" : "block";
});
</script>

</body>
</html>