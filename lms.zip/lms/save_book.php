<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $id = $_POST['id'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $publisher = $_POST['publisher'];
    $category = $_POST['category'];
    $year = $_POST['year'];
    $status = $_POST['availability_status'];

    // ADD BOOK
    if (empty($id)) {

        $stmt = $conn->prepare("INSERT INTO books 
            (`title`, `author`, `publisher`, `category`, `year`, `availability_status`, `date_of_entry`) 
            VALUES (?, ?, ?, ?, ?, ?, CURDATE())");

        $stmt->bind_param("ssssss", $title, $author, $publisher, $category, $year, $status);

        if ($stmt->execute()) {
            header("Location: admin_bookpage.php?msg=Book+Added+Successfully");
        } else {
            echo "Error: " . $stmt->error;
        }

    } 
    // EDIT BOOK
    else {

        $stmt = $conn->prepare("UPDATE books SET 
            `title`=?, 
            `author`=?, 
            `publisher`=?, 
            `category`=?, 
            `year`=?, 
            `availability_status`=? 
            WHERE id=?");

        $stmt->bind_param("ssssssi", $title, $author, $publisher, $category, $year, $status, $id);

        if ($stmt->execute()) {
            header("Location: admin_bookpage.php?msg=Book+Updated+Successfully");
        } else {
            echo "Error: " . $stmt->error;
        }
    }

    $stmt->close();
    $conn->close();
}
?>
