<?php
include 'db.php';

/* ================= INSERT ================= */
if (isset($_POST['save'])) {
    $name     = $_POST['name'];
    $language = $_POST['language'];
    $category = $_POST['category'];
    $status   = $_POST['status'];

    $pdf = "";
    if (!empty($_FILES['pdf']['name'])) {
        $pdf = time() . "_" . $_FILES['pdf']['name'];
        move_uploaded_file($_FILES['pdf']['tmp_name'], "uploads/" . $pdf);
    }

    mysqli_query($conn, "INSERT INTO newspapers 
        (Name, Language, Category, Status, pdf, created_date)
        VALUES ('$name','$language','$category','$status','$pdf',CURDATE())");

    header("Location: admin_newspapers.php");
    exit;
}

/* ================= UPDATE ================= */
if (isset($_POST['update'])) {
    $id       = $_POST['id'];
    $name     = $_POST['name'];
    $language = $_POST['language'];
    $category = $_POST['category'];
    $status   = $_POST['status'];

    if (!empty($_FILES['pdf']['name'])) {
        $pdf = time() . "_" . $_FILES['pdf']['name'];
        move_uploaded_file($_FILES['pdf']['tmp_name'], "uploads/" . $pdf);
        $pdfQuery = ", pdf='$pdf'";
    } else {
        $pdfQuery = "";
    }

    mysqli_query($conn, "UPDATE newspapers SET
        Name='$name',
        Language='$language',
        Category='$category',
        Status='$status'
        $pdfQuery
        WHERE id='$id'");

    header("Location: admin_newspapers.php");
    exit;
}

/* ================= DELETE ================= */
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM newspapers WHERE id='$id'");
    header("Location: admin_newspapers.php");
    exit;
}

/* ================= FETCH EDIT ================= */
$editData = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $res = mysqli_query($conn, "SELECT * FROM newspapers WHERE id='$id'");
    $editData = mysqli_fetch_assoc($res);
}

/* ================= SEARCH ================= */
$search = $_GET['search'] ?? '';
$where  = "";

if ($search !== '') {
    $search = mysqli_real_escape_string($conn, $search);
    $where = "WHERE 
        Name LIKE '%$search%' OR
        Language LIKE '%$search%' OR
        Category LIKE '%$search%'";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Newspapers - Admin Panel</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body { font-family: "Poppins", sans-serif; background: #f5f7fa; }

.top-header {
    width: calc(100% - 260px);
    margin-left: 260px;
    position: fixed;
    top: 0;
    height: 70px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: linear-gradient(90deg, #6a11cb, #2575fc);
    padding: 0 25px;
    color: white;
    z-index: 9999;
}

.sidebar {
    width: 260px;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    background: #1f2833;
    color: white;
    padding-top: 90px;
}

.sidebar h3 { text-align: center; color: #66fcf1; margin-bottom: 25px; }
.sidebar a { padding: 14px 25px; display: block; color: #c5c6c7; text-decoration: none; }
.sidebar a:hover, .sidebar a.active { background: #45a29e; color: white; border-radius: 5px; }

.main { margin-left: 260px; margin-top: 90px; padding: 20px 30px; }

.stats-card {
    background: linear-gradient(135deg, #11998e, #38ef7d);
    padding: 20px;
    border-radius: 12px;
    color: white;
}

.search-section {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}

.btn-add {
    background: #6a11cb;
    color: white;
    border-radius: 8px;
}

.table-box {
    background: white;
    padding: 20px;
    border-radius: 12px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="top-header">
<h1>📰 Newspapers</h1>
<a href="logout.php" class="btn btn-outline-light">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
<h3>Admin Panel</h3>
<a href="admin_dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
<a href="admin_bookpage.php"><i class="fa fa-book"></i> Books</a>
<a href="admin_members.php"><i class="fa fa-users"></i> Members</a>
<a href="admin_issued.php"><i class="fa fa-arrow-right"></i> Issued</a>
<a href="admin_returned.php"><i class="fa fa-check"></i> Returned</a>
<a href="admin_notreturned.php"><i class="fa fa-times-circle"></i> Not Returned</a>
<a href="admin_setting.php"><i class="fa fa-cog"></i> Settings</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="stats-card mb-4">
<h3>Total Newspapers</h3>
<h1>
<?php
$c = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS t FROM newspapers"));
echo $c['t'];
?>
</h1>
</div>

<form method="GET">
<div class="search-section">
<input type="text" name="search"
       value="<?= htmlspecialchars($_GET['search'] ?? '') ?>"
       class="form-control"
       placeholder="Search newspaper">

<button class="btn btn-primary">
<i class="fa fa-search"></i>
</button>

<button type="button" class="btn btn-add"
        data-bs-toggle="modal"
        data-bs-target="#addNewspaperModal">
<i class="fa fa-plus"></i> Add Newspaper
</button>
</div>
</form>

<div class="table-box">
<table class="table table-striped">
<thead class="table-dark">
<tr>
<th>ID</th>
<th>Name</th>
<th>Language</th>
<th>Category</th>
<th>Status</th>
<th>Date</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php
$res = mysqli_query($conn, "SELECT * FROM newspapers $where ORDER BY id DESC");
while ($row = mysqli_fetch_assoc($res)) {
?>
<tr>
<td><?= $row['id'] ?></td>
<td><?= $row['Name'] ?></td>
<td><?= $row['Language'] ?></td>
<td><?= $row['Category'] ?></td>
<td>
<?= $row['Status']=="Available"
? '<span class="badge bg-success">Available</span>'
: '<span class="badge bg-danger">Out</span>' ?>
</td>
<td><?= date('d-m-Y', strtotime($row['created_date'])) ?></td>
<td>
<a href="?edit=<?= $row['id'] ?>" class="btn btn-sm btn-primary">
<i class="fa fa-edit"></i>
</a>
<a href="?delete=<?= $row['id'] ?>"
   onclick="return confirm('Delete this newspaper?')"
   class="btn btn-sm btn-danger">
<i class="fa fa-trash"></i>
</a>
</td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
</div>

<!-- ADD MODAL -->
<div class="modal fade" id="addNewspaperModal">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<form method="POST" enctype="multipart/form-data">
<div class="modal-header">
<h5>Add Newspaper</h5>
<button class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body row">
<div class="col-md-6 mb-3">
<label>Name</label>
<input type="text" name="name" class="form-control" required>
</div>
<div class="col-md-6 mb-3">
<label>Language</label>
<input type="text" name="language" class="form-control" required>
</div>
<div class="col-md-6 mb-3">
<label>Category</label>
<input type="text" name="category" class="form-control" required>
</div>
<div class="col-md-6 mb-3">
<label>Status</label>
<select name="status" class="form-control">
<option>Available</option>
<option>Out of Stock</option>
</select>
</div>
<div class="col-12 mb-3">
<label>PDF</label>
<input type="file" name="pdf" class="form-control">
</div>
</div>
<div class="modal-footer">
<button name="save" class="btn btn-success">Save</button>
</div>
</form>
</div>
</div>
</div>

<!-- EDIT MODAL -->
<?php if ($editData): ?>
<div class="modal fade show" style="display:block;background:rgba(0,0,0,.5);">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?= $editData['id'] ?>">
<div class="modal-header">
<h5>Edit Newspaper</h5>
<a href="admin_newspapers.php" class="btn-close"></a>
</div>
<div class="modal-body row">
<div class="col-md-6 mb-3">
<label>Name</label>
<input type="text" name="name" value="<?= $editData['Name'] ?>" class="form-control">
</div>
<div class="col-md-6 mb-3">
<label>Language</label>
<input type="text" name="language" value="<?= $editData['Language'] ?>" class="form-control">
</div>
<div class="col-md-6 mb-3">
<label>Category</label>
<input type="text" name="category" value="<?= $editData['Category'] ?>" class="form-control">
</div>
<div class="col-md-6 mb-3">
<label>Status</label>
<select name="status" class="form-control">
<option <?= $editData['Status']=="Available"?"selected":"" ?>>Available</option>
<option <?= $editData['Status']=="Out of Stock"?"selected":"" ?>>Out of Stock</option>
</select>
</div>
<div class="col-12 mb-3">
<label>PDF (optional)</label>
<input type="file" name="pdf" class="form-control">
</div>
</div>
<div class="modal-footer">
<button name="update" class="btn btn-primary">Update</button>
</div>
</form>
</div>
</div>
</div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>