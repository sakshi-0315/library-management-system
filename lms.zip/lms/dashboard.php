<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Library Management System</title>
    <link rel="stylesheet" href="style.css">

    <style>

    /* GLOBAL */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f3f4f6;
}

/* SIDEBAR */
.sidebar {
    width: 230px;
    height: 100vh;
    background: #1d2327;
    color: #fff;
    position: fixed;
    top: 0; 
    left: 0;
    padding-top: 20px;
}

.sidebar h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 22px;
}

.sidebar a {
    display: block;
    padding: 12px 20px;
    color: #eee;
    text-decoration: none;
    font-size: 16px;
    border-left: 3px solid transparent;
}

.sidebar a:hover,
.sidebar a.active {
    background: #2c3338;
    border-left: 3px solid #00aaff;
    color: #fff;
}

.logout {
    margin-top: 30px;
    background: crimson !important;
    color: #fff !important;
}

/* MAIN CONTENT */
.main {
    margin-left: 230px;
    padding: 20px;
}

/* TOP BAR */
/* TOP BAR */
.topbar {
    background: linear-gradient(90deg, #003768ff, #2b568eff);
    padding: 15px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-radius: 10px;
    margin-bottom: 20px;
    color: #fff;
}

.search-box input {
    padding: 8px;
    width: 250px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.icons {
    font-size: 24px;
}

/* CARDS GRID */
.cards {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-top: 20px;
}

/* CARD BASE STYLE */
.card {
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 0 8px rgba(0,0,0,0.3);
    text-align: center;
    transition: 0.3s ease;
    color: white;  /* ensure text is readable on gradients */
}

.card:hover {
    transform: translateY(-5px);
}

/* INDIVIDUAL CARD COLORS */
.books {
     background: linear-gradient(135deg, #895200ff, #c29455ff);
}

.issue {
    background: linear-gradient(135deg, #005a01ff, #81b83eff);
}

.return {
     background: linear-gradient(135deg,  #005145ff, #177d6cff);
  
}

.history {
    background: linear-gradient(135deg, #7d032bff, #835e6aff);
}


/* WHITE TEXT */
.card p {
    color: white;
    font-size: 16px;
    margin: 8px 0;
}

/* TURN ICONS WHITE */
.card img {
    width: 80px;
    height: 80px;
    margin-bottom: 10px;
    filter: brightness(0) invert(1);
}

/* PERFECT BLUE BUTTON */
.card button {
    width: 100%;
    padding: 12px;
    background: #007bff;
    color: #ffffff;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.2s;
    margin-top: 10px;
}

.card button:hover {
    background: #0056d2;
}

.card button:active {
    transform: scale(0.97);
}

/* BELL DROPDOWN MENU */
.icons {
    font-size: 24px;
    position: relative;
}

.bell-menu {
    display: none; /* hidden by default */
    position: absolute;
    right: 0;
    top: 30px;
    background: white;
    border: 1px solid #ccc;
    border-radius: 8px;
    width: 160px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    z-index: 100;
}

.bell-menu a {
    display: block;
    padding: 10px 15px;
    color: #0B2E33;
    text-decoration: none;
    font-weight: 500;
    transition: background 0.2s;
}

.bell-menu a:hover {
    background: #4F7CB2;
    color: white;
}

/* FORM + TABLE UI (ISSUE/RETURN BOOK) */
.form-container,
.table-container {
    background: white;
    padding: 20px;
    margin: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.form-container h2,
.table-container h2 {
    margin-bottom: 15px;
}

.form-container label {
    display: block;
    margin-top: 10px;
    font-weight: 600;
}

.form-container input {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 6px;
}

.btn {
    margin-top: 15px;
    padding: 10px 18px;
    background: #1b7ccbff;
    border: none;
    color: white;
    font-weight: bold;
    border-radius: 6px;
    cursor: pointer;
}

.btn:hover {
    background: #0f6bb1ff;
}

.table-container table {
    width: 100%;
    border-collapse: collapse;
}

.table-container th {
    background: #115e9dff;
    color: white;
}

    /* HISTORY TABLE (same style, no dashboard UI change) */
    .history-table-box {
        background: #fff;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        margin-top: 30px;
    }

    .history-table-box h2 {
        margin-bottom: 15px;
        color: #444;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th {
        background: #6884e0ff;
        padding: 12px;
        text-align: left;
    }

    td {
        padding: 12px;
        border-bottom: 1px solid #e5e5e5;
    }

    tr:hover {
        background: #f7f7f7;
    }
    </style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>USER</h2>
    <a href="dashboard.php" class="manu active">Dashboard</a>
    <a href="all_books.php">All Books</a>
    <a href="issue_book.php">Issue Book</a>
    <a href="return_book.php">Return Book</a>
    <a href="#" class="logout">Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">

<!-- TOP BAR -->
<div class="topbar">    
    <h1>Library Management System</h1>

    <div class="search-box">
        <input type="text" placeholder="Search books...">
    


        <span class="bell" id="bell">🔔</span>
        <div class="bell-menu" id="bellMenu">
            <a href="#">New Books</a>
            <a href="#">Return Book Date</a>
        </div>
    </div>
</div>

<div class="cards">

    <div class="card books">
        <img src="https://cdn-icons-png.flaticon.com/512/29/29302.png">
        <p>Library</p>
        <!-- <button>Click here to go</button> -->
    </div>

    <div class="card history">
        <img src="https://cdn-icons-png.flaticon.com/512/29/29312.png">
        <p>All Books</p>
        <p>Total Books:</p>
        <!-- <button onclick="window.location.href='all_books.php'">Click here to go</button> -->
    </div>

    <div class="card issue">
        <img src="https://cdn-icons-png.flaticon.com/512/3592/3592660.png">
        <p>Issue Books</p>
        <p>Total Issue Books:</p>
        <!-- <button onclick="window.location.href='issue_book.php'">Click here to go</button> -->
    </div>

    <div class="card return">
        <img src="https://cdn-icons-png.flaticon.com/512/860/860798.png">
        <p>Return Books</p>
        <p>Total Return Books:</p>
        <!-- <button onclick="window.location.href='return_book.php'">Click here to go</button> -->
    </div>

</div>

<!-- ✅ HISTORY TABLE ADDED BELOW DASHBOARD -->
<div class="history-table-box">
    <h2>Recent History</h2>

    <?php
    // Example history data (replace with DB later)
    $history = [
        ["id"=>1,"book"=>"Sapiens","user"=>101,"issue"=>"2025-12-01","return"=>"2025-12-15"],
        ["id"=>2,"book"=>"India: A History","user"=>102,"issue"=>"2025-12-05","return"=>"2025-12-20"],
        ["id"=>3,"book"=>"The Silk Roads","user"=>103,"issue"=>"2025-12-10","return"=>"2025-12-30"],
    ];
    ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Book Name</th>
                <th>User ID</th>
                <th>Issue Date</th>
                <th>Return Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($history as $h): ?>
            <tr>
                <td><?= $h['id'] ?></td>
                <td><?= $h['book'] ?></td>
                <td><?= $h['user'] ?></td>
                <td><?= $h['issue'] ?></td>
                <td><?= $h['return'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</div>

<script>
const bell = document.getElementById('bell');
const bellMenu = document.getElementById('bellMenu');

bell.addEventListener('click', () => {
    bellMenu.style.display =
        bellMenu.style.display === 'block' ? 'none' : 'block';
});
</script>

</body>
</html>
