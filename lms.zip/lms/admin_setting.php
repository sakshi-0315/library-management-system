<?php
session_start();
include 'db.php';

// Protect page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user data
$stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("User not found");
}

$user = $result->fetch_assoc();

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name  = $_POST['name'];
    $email = $_POST['email'];

    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $update = $conn->prepare(
            "UPDATE users SET name=?, email=?, password=? WHERE id=?"
        );
        $update->bind_param("sssi", $name, $email, $password, $user_id);
    } else {
        $update = $conn->prepare(
            "UPDATE users SET name=?, email=? WHERE id=?"
        );
        $update->bind_param("ssi", $name, $email, $user_id);
    }

    $update->execute();
    echo "<script>alert('Settings Updated Successfully');</script>";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Settings - Admin Panel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
    body { font-family: "Poppins", sans-serif; background: #f5f7fa; }

    .top-header {
        width: calc(100% - 260px);
        margin-left: 260px;
        position: fixed;
        top: 0;
        height: 70px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: linear-gradient(90deg, #6a11cb, #2575fc);
        padding: 0 25px;
        color: white;
        z-index: 9999;
    }

    .sidebar {
        width: 260px;
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        background: #1f2833;
        color: white;
        padding-top: 90px;
    }
    .sidebar h3 { text-align: center; color: #66fcf1; margin-bottom: 25px; }
    .sidebar a { padding: 14px 25px; display: block; color: #c5c6c7; text-decoration: none; }
    .sidebar a:hover { background: #45a29e; color: white; border-radius: 5px; }

    .main { margin-left: 260px; margin-top: 90px; padding: 20px 30px; }

    .settings-box {
        background: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }

    .btn-save {
        background: #6a11cb;
        color: white;
        border-radius: 8px;
        font-weight: 600;
    }
</style>
</head>

<body>

<!-- HEADER -->
<div class="top-header">
    <h1 style="font-size:22px; font-weight:700;">⚙ Settings</h1>

    <div style="display:flex; gap:20px; align-items:center;">
        <i class="fa fa-bell" style="font-size:20px; cursor:pointer;"></i>
        <span>Admin</span>
        <a href="login.php" class="btn btn-outline-light">
            <i class="fa fa-sign-out-alt"></i> Logout
        </a>
    </div>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="admin_dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="admin_bookpage.php"><i class="fa fa-book"></i> Books</a>
    <a href="admin_newspapers.php"><i class="fa fa-newspaper"></i> Newspapers</a>
    <a href="admin_members.php"><i class="fa fa-users"></i> Members</a>
    <a href="admin_issued.php"><i class="fa fa-arrow-right"></i> Issued</a>
    <a href="admin_returned.php"><i class="fa fa-check"></i> Returned</a>
    <a href="admin_notreturned.php"><i class="fa fa-times-circle"></i> Not Returned</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">
    <div class="settings-box">
        <h4>Admin Profile</h4>

       <form method="POST">
    <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" name="name" class="form-control"
               value="<?= htmlspecialchars($user['name']) ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control"
               value="<?= htmlspecialchars($user['email']) ?>" required>
    </div>

   

    <div class="mb-3">
        <label class="form-label">Change Password</label>
        <input type="password" name="password" class="form-control"
               placeholder="Leave blank to keep old password">
    </div>

    <button type="submit" class="btn btn-save">Save Settings</button>
</form>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>