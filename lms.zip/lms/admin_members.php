<?php
include 'db.php';

/* ADD MEMBER */
if (isset($_POST['save_member'])) {
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $date  = $_POST['joining_date'];

    mysqli_query($conn, "INSERT INTO members 
    (name,email,phone_no,joining_date,book_issued)
    VALUES ('$name','$email','$phone','$date',0)");
}

/* DELETE MEMBER */
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM members WHERE id=$id");
    header("Location: admin_members.php");
}

/* UPDATE MEMBER */
if (isset($_POST['update_member'])) {
    $id    = $_POST['id'];
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $date  = $_POST['joining_date'];

    mysqli_query($conn, "UPDATE members SET
        name='$name',
        email='$email',
        phone_no='$phone',
        joining_date='$date'
        WHERE id=$id");
}

/* FETCH */
$result = mysqli_query($conn, "SELECT * FROM members ORDER BY id DESC");
$count  = mysqli_num_rows($result);
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

$result = mysqli_query($conn, "
    SELECT * FROM members 
    WHERE name LIKE '%$search%' 
       OR email LIKE '%$search%'
    ORDER BY id DESC
");

$count = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM members"));
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Members - Admin Panel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
    body { font-family: "Poppins", sans-serif; background: #f5f7fa; }

    /* TOP HEADER */
    .top-header {
        width: calc(100% - 260px);
        margin-left: 260px;
        position: fixed;
        top: 0;
        left: 0;
        height: 70px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: linear-gradient(90deg, #6a11cb, #2575fc);
        padding: 0 25px;
        color: white;
        z-index: 9999;
        border-bottom: 1px solid rgba(255,255,255,0.2);
    }

    /* SIDEBAR */
    .sidebar {
        width: 260px;
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        background: #1f2833;
        color: white;
        padding-top: 90px;
        z-index: 9998;
    }
    .sidebar h3 { text-align: center; color: #66fcf1; margin-bottom: 25px; }
    .sidebar a { padding: 14px 25px; display: block; color: #c5c6c7; text-decoration: none; }
    .sidebar a:hover, 
    .sidebar a.active { background: #45a29e; color: white; border-radius: 5px; }

    /* MAIN CONTENT */
    .main { margin-left: 260px; margin-top: 90px; padding: 20px 30px; }

    /* Stats card */
    .stats-card {
        background: linear-gradient(135deg, #11998e, #38ef7d);
        padding: 20px;
        border-radius: 12px;
        color: white;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    /* Search + Add Button */
    .search-section {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 20px;
    }
    .search-section input {
        padding: 10px 15px;
        border-radius: 8px;
        border: 1px solid #ccc;
        width: 100%;
    }
    .btn-add {
        background: #6a11cb;
        color: white;
        border: none;
        padding: 10px 18px;
        border-radius: 8px;
        font-size: 15px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .btn-add:hover {
        background: #5710a7;
    }

    /* Table Box */
    .table-box {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
</style>
</head>
<body>

<!-- HEADER -->
<div class="top-header">
    <h1 style="font-size:22px; font-weight:700;">👥 Members</h1>
    
    <div style="display:flex; gap:20px; align-items:center;">
        <i class="fa fa-bell" style="font-size:20px; cursor:pointer;"></i>
        <div class="admin-info" style="display:flex; align-items:center; gap:10px;">
            
            <span>Admin</span>
        </div>
        <!-- Logout Button -->
        <a href="logout.php" class="btn btn-outline-light" style="border-radius:8px; padding:5px 12px; font-weight:600;">
            <i class="fa fa-sign-out-alt"></i> Logout
        </a>
    </div>
</div>
<!-- NOTIFICATION DROPDOWN -->
<div id="notifyBox" style="
    position: fixed;
    top: 75px;
    right: 30px;
    width: 300px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    display: none;
    z-index: 999999;
">
    <ul style="list-style:none; margin:0; padding:10px;">
        <li style="padding:10px; border-bottom:1px solid #eee;">
            <span style="color:green;">📘 New Book Added:</span> Python Basics
        </li>
        <li style="padding:10px; border-bottom:1px solid #eee;">
            <span style="color:red;">⏳ Overdue:</span> Web Dev Book
        </li>
        <li style="padding:10px;">
            <span style="color:blue;">👤 New Member:</span> Rohan Patel
        </li>
    </ul>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="admin_dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="admin_bookpage.php"><i class="fa fa-book"></i> Books</a>
    <a href="admin_newspapers.php"><i class="fa fa-newspaper"></i> Newspapers</a>
    <a href="admin_issued.php"><i class="fa fa-arrow-right"></i> Issued</a>
    <a href="admin_returned.php"><i class="fa fa-check"></i> Returned</a>
    <a href="admin_notreturned.php"><i class="fa fa-times-circle"></i> Not Returned</a>
    <a href="admin_setting.php"><i class="fa fa-cog"></i> Settings</a>
    <a href="#"><i class="fa fa-sign-out-alt"></i>Logout </a>
</div>

<!-- MAIN CONTENT -->
<div class="main">

    <!-- Members Count -->
    <div class="stats-card mb-4">
        <h3>Total Members</h3>
        <h1 style="font-size:45px; margin:0;"><?php echo $count; ?></h1>
    </div>

    <!-- Search + Add Button -->
    <form method="GET" class="search-section">
    <input type="text" name="search" placeholder="Search members by name or email"
           value="<?php echo htmlspecialchars($search); ?>">

    <button type="submit" name="search_btn" class="btn-add">
        <i class="fa fa-search"></i> Search
    </button>


    <button class="btn-add" type="button" data-bs-toggle="modal" data-bs-target="#addMemberModal">
        <i class="fa fa-plus"></i> Add Member
    </button>
</form>

    <!-- Members Table -->
    <table class="table table-hover table-striped">
    <thead class="table-dark">
       <tr>
    <th>#ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Issued Books</th>
    <th>Joined On</th>
    <th>Action</th>
</tr>

    </thead>
   <tbody>
<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['name'] ?></td>
    <td><?= $row['email'] ?></td>
    <td><?= $row['phone_no'] ?></td>
    <td><?= $row['book_issued'] ?></td>
    <td><?= date('d-m-Y', strtotime($row['joining_date'])) ?></td>

    <td>
        <!-- EDIT -->
        <button class="btn btn-sm btn-warning"
            data-bs-toggle="modal"
            data-bs-target="#edit<?= $row['id'] ?>">
            <i class="fa fa-edit"></i>
        </button>

        <!-- DELETE -->
        <a href="?delete=<?= $row['id'] ?>"
           onclick="return confirm('Delete member?')"
           class="btn btn-sm btn-danger">
            <i class="fa fa-trash"></i>
        </a>
    </td>
</tr>

<!-- EDIT MODAL (UI SAME BOOTSTRAP) -->
<div class="modal fade" id="edit<?= $row['id'] ?>">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <div class="modal-header">
          <h5>Edit Member</h5>
          <button class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">
            <input type="hidden" name="id" value="<?= $row['id'] ?>">

            <div class="mb-3">
                <label>Name</label>
                <input type="text" name="name" value="<?= $row['name'] ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" value="<?= $row['email'] ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label>Phone</label>
                <input type="text" name="phone" value="<?= $row['phone_no'] ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label>Joining Date</label>
                <input type="date" name="joining_date" value="<?= $row['joining_date'] ?>" class="form-control">
            </div>
        </div>

        <div class="modal-footer">
          <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button class="btn btn-primary" name="update_member">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php } ?>
</tbody>


</table>

    </div>

</div>

<!-- ADD MEMBER MODAL -->
<div class="modal fade" id="addMemberModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title">Add New Member</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <form method="POST">
    <div class="mb-3">
        <label>Full Name</label>
        <input type="text" name="name" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Phone</label>
        <input type="text" name="phone" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Date of Joining</label>
        <input type="date" name="joining_date" class="form-control" required>
    </div>

    <button class="btn btn-primary" name="save_member">Save Member</button>
</form>

      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save Member</button>
      </div>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const bellIcon = document.querySelector('.fa-bell');
const notifyBox = document.getElementById('notifyBox');

// Toggle notification box on bell click
bellIcon.addEventListener('click', () => {
    if (notifyBox.style.display === 'none' || notifyBox.style.display === '') {
        notifyBox.style.display = 'block';
    } else {
        notifyBox.style.display = 'none';
    }
});

// Close notification box if clicked outside
document.addEventListener('click', (e) => {
    if (!notifyBox.contains(e.target) && !bellIcon.contains(e.target)) {
        notifyBox.style.display = 'none';
    }
});
</script>

</body>
</html>