<?php
session_start();
include "db.php";

// Fetch all books
$books = $conn->query("SELECT * FROM books ORDER BY id DESC");
$totalBooks = $books->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Books Management | Admin Panel</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body { background:#f5f7fa; font-family:Poppins,sans-serif; margin:0; }
.top-header {
    position:fixed; top:0; left:0; height:70px;
    width:calc(100% - 260px); margin-left:260px;
    display:flex; align-items:center; justify-content:space-between;
    background:linear-gradient(90deg,#6a11cb,#2575fc);
    padding:0 25px; color:#fff; font-weight:700; z-index:9999;
}
.sidebar {
    position:fixed; top:0; left:0; width:260px; height:100vh;
    background:#1f2833; color:#fff; padding-top:90px;
}
.sidebar h3 { text-align:center; color:#66fcf1; margin-bottom:25px; }
.sidebar a {
    padding:14px 25px; display:block; font-size:16px;
    color:#c5c6c7; text-decoration:none;
}
.sidebar a:hover { background:#45a29e; color:#fff; border-radius:5px; }
.main { margin-left:260px; margin-top:90px; padding:20px; }
.card-book {
    border-radius:10px; background:#fff;
    box-shadow:0 2px 8px rgba(0,0,0,.1);
}
.card-book:hover { transform:scale(1.02); }
.badge-status { padding:5px 10px; border-radius:5px; font-size:13px; color:#fff; }
.available { background:#28a745; }
.issued { background:#dc3545; }
.modal-header { background:#2575fc; color:#fff; }
</style>
</head>

<body>

<div class="top-header">
    <h1 style="font-size:24px;">📚 Library Management System</h1>
    <a href="logout.php" class="btn btn-outline-light">
        <i class="fa fa-sign-out-alt"></i> Logout
    </a>
</div>

<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="admin_dashboard.php"><i class="fa fa-book"></i> Dashboard</a>
    <a href="admin_members.php"><i class="fa fa-users"></i> Members</a>
    <a href="admin_newspapers.php"><i class="fa fa-newspaper"></i> Newspapers</a>
    <a href="admin_issued.php"><i class="fa fa-arrow-right"></i> Issued</a>
    <a href="admin_returned.php"><i class="fa fa-check"></i> Returned</a>
    <a href="admin_notreturned.php"><i class="fa fa-times-circle"></i> Not Returned</a>
    <a href="admin_setting.php"><i class="fa fa-cog"></i> Settings</a>
</div>

<div class="main">

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2>Books</h2>
        <div class="card shadow-sm border-0 mt-2" style="border-radius:12px;">
    <div class="card-body d-flex align-items-center justify-content-between">
        <div>
            <h6 class="text-muted mb-1">Total Books</h6>
            <h2 class="mb-0 font-weight-bold text-primary">
                <?= $totalBooks ?>
            </h2>
        </div>
        <div style="
            background:linear-gradient(135deg,#6a11cb,#2575fc);
            color:white;
            width:55px;
            height:55px;
            display:flex;
            align-items:center;
            justify-content:center;
            border-radius:50%;
            font-size:22px;
        ">
            <i class="fa fa-book"></i>
        </div>
    </div>
</div>

    </div>
    <button class="btn btn-primary" data-toggle="modal" data-target="#bookModal" onclick="openAddBook()">+ Add Book</button>
</div>

<div class="row mb-3">
    <div class="col-md-4">
        <input type="text" id="searchInput" class="form-control" placeholder="Search book">
    </div>
    <div class="col-md-3">
        <select id="statusFilter" class="form-control">
            <option value="">All Status</option>
            <option value="Available">Available</option>
            <option value="Issued">Issued</option>
        </select>
    </div>
</div>

<div class="row">
<?php while($row = $books->fetch_assoc()):
$badgeClass = ($row['availability_status']=="Available")?"available":"issued"; ?>
<div class="col-md-4 mb-4 book-card">
    <div class="card-book p-3">
        <h5><?= htmlspecialchars($row['title']) ?></h5>
        <p><strong>Author:</strong> <?= htmlspecialchars($row['author']) ?></p>
        <p><strong>Publisher:</strong> <?= htmlspecialchars($row['publisher']) ?></p>
        <p><strong>Category:</strong> <?= htmlspecialchars($row['category']) ?></p>
        <p><strong>Year:</strong> <?= $row['year'] ?></p>
        <span class="badge-status <?= $badgeClass ?>"><?= $row['availability_status'] ?></span>
        <div class="mt-2">
            <i class="fa fa-edit text-primary" data-toggle="modal" data-target="#bookModal"
               onclick='openEditBook(<?= json_encode($row) ?>)'></i>
            <i class="fa fa-trash text-danger" onclick="deleteBook(<?= $row['id'] ?>)"></i>
        </div>
    </div>
</div>
<?php endwhile; ?>
</div>
</div>

<!-- MODAL -->
<div class="modal fade" id="bookModal">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST" action="save_book.php">
<div class="modal-header">
    <h5 id="modalTitle">Add Book</h5>
    <button class="close" data-dismiss="modal">&times;</button>
</div>

<div class="modal-body">
<input type="hidden" name="id" id="book_id">

<input type="text" name="title" id="title" class="form-control mb-2" placeholder="Title" required>
<input type="text" name="author" id="author" class="form-control mb-2" placeholder="Author" required>

<!-- Publisher Dropdown -->
<select name="publisher" id="publisher" class="form-control mb-2">
    <option value="">Select Publisher</option>
    <option>O'Reilly</option>
    <option>Penguin</option>
    <option>McGraw Hill</option>
    <option>Oxford</option>
</select>

<!-- Category Dropdown -->
<select name="category" id="category" class="form-control mb-2">
    <option value="">Select Category</option>
    <option>Programming</option>
    <option>Science</option>
    <option>Mathematics</option>
    <option>Literature</option>
</select>

<input type="text" name="year" id="year" class="form-control mb-2" placeholder="Year">

<select name="availability_status" id="availability_status" class="form-control">
    <option value="Available">Available</option>
    <option value="Issued">Issued</option>
</select>
</div>

<div class="modal-footer">
<button class="btn btn-success">Save</button>
<button class="btn btn-secondary" data-dismiss="modal">Cancel</button>
</div>
</form>
</div>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
function openAddBook(){
    document.getElementById("modalTitle").innerText="Add Book";
    document.querySelector("form").reset();
    document.getElementById("book_id").value="";
}
function openEditBook(book){
    document.getElementById("modalTitle").innerText="Edit Book";
    for(let k in book){
        if(document.getElementById(k)){
            document.getElementById(k).value = book[k];
        }
    }
}
function deleteBook(id){
    if(confirm("Delete this book?")){
        window.location="delete_book.php?id="+id;
    }
}
document.getElementById("searchInput").addEventListener("keyup",filterBooks);
document.getElementById("statusFilter").addEventListener("change",filterBooks);

function filterBooks(){
    let s=document.getElementById("searchInput").value.toLowerCase();
    let st=document.getElementById("statusFilter").value;
    document.querySelectorAll(".book-card").forEach(c=>{
        let t=c.innerText.toLowerCase();
        let b=c.querySelector(".badge-status").innerText;
        c.style.display=(t.includes(s)&&(st==""||b==st))?"block":"none";
    });
}
</script>

</body>
</html>
