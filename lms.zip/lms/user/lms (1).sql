-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2025 at 10:25 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `author` varchar(100) NOT NULL,
  `publisher` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `availability_status` varchar(50) NOT NULL,
  `date_of_entry` date NOT NULL,
  `issued_to` varchar(100) NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `return_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `publisher`, `category`, `year`, `availability_status`, `date_of_entry`, `issued_to`, `issue_date`, `due_date`, `return_date`) VALUES
(6, 'python', 'xyz', 'McGraw Hill', 'Programming', 2018, 'Issued', '2025-12-15', '', '0000-00-00', '0000-00-00', '0000-00-00'),
(9, 'algebra', 'def', 'Oxford', 'Mathematics', 2009, 'Available', '2025-12-15', '', '0000-00-00', '0000-00-00', '0000-00-00'),
(10, 'The prisoner', 'Emily', 'Oxford', 'Literature', 2010, 'Available', '2025-12-15', '', '0000-00-00', '0000-00-00', '0000-00-00'),
(11, 'chemistry', 'asd', 'McGraw Hill', 'Science', 2012, 'Issued', '2025-12-15', '', '0000-00-00', '0000-00-00', '0000-00-00'),
(13, 'The prisoner', 'Emily', 'Oxford', 'Literature', 2010, 'Available', '2025-12-15', '', '0000-00-00', '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_no` int(11) NOT NULL,
  `joining_date` date NOT NULL,
  `book_issued` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `email`, `phone_no`, `joining_date`, `book_issued`) VALUES
(1, 'Viya Hun', 'viya67@gmail.com', 2147483647, '2025-12-15', 0),
(4, 'sakshi asharawala', 'sakshikamal05@gmail.com', 2147483647, '2025-12-03', 0);

-- --------------------------------------------------------

--
-- Table structure for table `newspapers`
--

CREATE TABLE `newspapers` (
  `id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Language` varchar(100) NOT NULL,
  `Category` varchar(100) NOT NULL,
  `Status` varchar(100) NOT NULL,
  `pdf` varchar(255) NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `newspapers`
--

INSERT INTO `newspapers` (`id`, `Name`, `Language`, `Category`, `Status`, `pdf`, `created_date`) VALUES
(1, 'abc', 'Hindi', 'Weekly', 'Available', 'vb.net.docx', '2025-12-15');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'Sakshi Asharawala ', 'sakshikamal05@gmail.com', '$2y$10$RDXggU1vepKKrbpSYzKBj.7tupDsGvjS.d8nOs3mRQ/06Tuxptv1.', '2025-12-11 08:13:08'),
(2, 'viya', 'viya@gmail.com', '$2y$10$6CRsB6S.JH13vyt/TrPUMOwbEyWcAz3DSJji5ApdrBj.xoldbKmbW', '2025-12-12 07:34:53'),
(3, 'admin', 'admin@gmail.com', '$2y$10$mLw5iiPtc/H2EEnLj.hKueQaRA/QVpa5ZdJAenUVc948k8kg63lVu', '2025-12-12 07:38:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newspapers`
--
ALTER TABLE `newspapers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `newspapers`
--
ALTER TABLE `newspapers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
