<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>History / Book Details</title>

<style>
/* =============== GLOBAL STYLE =============== */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6fb;
}

/* =============== SIDEBAR =============== */
.sidebar {
    width: 230px;
    height: 100vh;
    background: #1e252b;
    position: fixed;
    top: 0;
    left: 0;
    color: white;
    padding-top: 20px;
}

.sidebar h2 {
    text-align: center;
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    padding: 12px 20px;
    color: #dcdcdc;
    text-decoration: none;
    font-size: 16px;
}

.sidebar a:hover {
    background: #2c333a;
}

.sidebar a.active {
    background: #2c333a;
    color: #fff;
    border-left: 4px solid #00a8ff;
}

.sidebar .logout {
    background: #d61347;
    margin-top: 30px;
    color: white;
}

/* =============== MAIN CONTENT =============== */
.main {
    margin-left: 250px;
    padding: 30px;
}

/* TITLE */
.title {
    font-size: 28px;
    font-weight: bold;
}

.subtitle {
    color: #777;
    margin-bottom: 25px;
}

/* =============== TOP CARDS =============== */
.cards {
    display: flex;
    gap: 20px;
    margin-bottom: 30px;
}

.card {
    flex: 1;
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}

.card h3 {
    font-size: 18px;
    color: #555;
}

.card p {
    font-size: 28px;
    font-weight: bold;
}

/* =============== TABLE =============== */
.table-box {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}

.table-box h2 {
    margin-bottom: 10px;
    color: #444;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #eef2ff;
    padding: 12px;
    font-size: 14px;
    color: #444;
}

td {
    padding: 12px;
    border-bottom: 1px solid #e5e5e5;
}

tr:hover {
    background: #f7f7f7;
}

</style>

</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>USER</h2>
    <a href="dashboard.php" >Dashboard</a>
    <a href="all_books.php" >All Books</a>
    <a href="issue_book.php" >Issue Book</a>
    <a href="return_book.php" >Return Book</a>
    <a href="history_book.php" class="manu active">History</a>
    <a href="#" class="logout">Logout</a>
</div>

<!-- MAIN CONTENT -->   
<div class="main">
    <div class="title">Book History / Issue Details</div>
    <div class="subtitle">View issued and returned book details</div>


    <!-- TABLE -->
    <div class="table-box">
        <h2>History Book Table</h2>

        <?php
        // Example history book data
        $books = [
            ["id"=>1, "book_name"=>"Sapiens", "user_id"=>101, "issue_date"=>"2025-12-01", "return_date"=>"2025-12-15"],
            ["id"=>2, "book_name"=>"India: A History", "user_id"=>102, "issue_date"=>"2025-12-05", "return_date"=>"2025-12-20"],
            ["id"=>3, "book_name"=>"Guns, Germs, and Steel", "user_id"=>103, "issue_date"=>"2025-12-10", "return_date"=>"2025-12-25"],
            ["id"=>4, "book_name"=>"The Silk Roads", "user_id"=>104, "issue_date"=>"2025-12-15", "return_date"=>"2025-12-30"],
            ["id"=>5, "book_name"=>"The History of the Ancient World", "user_id"=>105, "issue_date"=>"2025-12-20", "return_date"=>"2026-01-05"],
        ];
        ?>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Book Name</th>
                    <th>User ID</th>
                    <th>Issue Date</th>
                    <th>Return Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($books as $b): ?>
                    <tr>
                        <td><?php echo $b["id"]; ?></td>
                        <td><?php echo $b["book_name"]; ?></td>
                        <td><?php echo $b["user_id"]; ?></td>
                        <td><?php echo $b["issue_date"]; ?></td>
                        <td><?php echo $b["return_date"]; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<!-- ✅ SCRIPT FOR SINGLE ACTIVE -->
<script>
    const menuLinks = document.querySelectorAll('.menu');

    menuLinks.forEach(link => {
        link.addEventListener('click', function () {
            menuLinks.forEach(item => item.classList.remove('active'));
            this.classList.add('active');
        });
    });
</script>

</body>
</html>
