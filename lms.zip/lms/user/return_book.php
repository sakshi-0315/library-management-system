<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Return Book</title>

<style>
/* =============== GLOBAL STYLE =============== */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6fb;
}

/* =============== SIDEBAR =============== */
.sidebar {
    width: 230px;
    height: 100vh;
    background: #1e252b;
    position: fixed;
    top: 0;
    left: 0;
    color: white;
    padding-top: 20px;
}

.sidebar h2 {
    text-align: center;
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    padding: 12px 20px;
    color: #dcdcdc;
    text-decoration: none;
    font-size: 16px;
}

.sidebar a:hover {
    background: #2c333a;
}

.sidebar a.active {
    background: #2c333a;
    color: #fff;
    border-left: 4px solid #00a8ff;
}

.sidebar .logout {
    background: #d61347;
    margin-top: 30px;
    color: white;
}

/* =============== MAIN CONTENT =============== */
.main {
    margin-left: 250px;
    padding: 30px;
}

/* =============== TOP BAR =============== */
.topbar {
    background: linear-gradient(90deg, #023c6fff, #2e5c98ff) !important;
    padding: 20px 25px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

/* TITLE */
.title {
    font-size: 28px;
    font-weight: bold;
    color: #ffffff;
}

/* SUBTITLE */
.subtitle {
    color: #e0e6f0;
    margin-top: 6px;
    font-size: 15px;
}


/* =============== TOP CARDS =============== */
.cards {
    display: flex;
    gap: 20px;
    margin-bottom: 30px;
}

.card {
    flex: 1;
    background: linear-gradient(135deg, #016253ff, #209c88ff); /* gradient background */
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    color: white; /* ensures text is readable on gradient */
}

.card h3 {
    font-size: 18px;
    color: white; /* update text color for readability */
}

.card p {
    font-size: 28px;
    font-weight: bold;
    color: white; /* update text color for readability */
}


/* =============== TABLE =============== */
.table-box {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}

.table-box h2 {
    margin-bottom: 10px;
    color: #444;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #eef2ff;
    padding: 12px;
    font-size: 14px;
    color: #444;
}

td {
    padding: 12px;
    border-bottom: 1px solid #e5e5e5;
}

tr:hover {
    background: #f7f7f7;
}

/* BUTTON */
.return-btn {
    padding: 7px 14px;
    background: #4f46e5;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

.return-btn:hover {
    background: #3730a3;
}
</style>

</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>USER</h2>
    <a href="dashboard.php" class="menu">Dashboard</a>
    <a href="all_books.php" class="menu">All Books</a>
    <!-- <a href="#">Add Book</a> -->
    <a href="issue_book.php" class="menu">Issue Book</a>
    <a href="return_book.php" class="menu active">Return Book</a>
    <a href="history_book.php" class="menu">History</a>
    <a href="#" class="logout">Logout</a>
</div>

<!-- MAIN CONTENT -->   
<div class="main">
<div class="topbar">
    <div class="title">Return Book Details</div>
    <div class="subtitle">View issued books and process returns</div>
</div>

    <!-- TOP CARDS -->      
    <div class="cards">
        <div class="card">
            <h3>Total Issued Books</h3>
            <p>12</p>
        </div>

        <div class="card">
            <h3>Total Returned Books</h3>
            <p>08</p>
        </div>
    </div>

    <!-- TABLE -->
    <div class="table-box">
        <h2>Return Book Table</h2>

        <table>
            <thead>
                <tr>
                    <th>Book ID</th>
                    <th>Book Name</th>
                    <th>Issue Date</th>
                    <th>Return Date</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

                <tr>
                    <td>BK001</td>
                    <td>Java Programming</td>
                    <td>2025-12-01</td>
                    <td>2025-12-10</td>
                    <td><button class="return-btn">Return</button></td>
                </tr>

                <tr>
                    <td>BK002</td>
                    <td>Database Systems</td>
                    <td>2025-12-03</td>
                    <td>2025-12-11</td>
                    <td><button class="return-btn">Return</button></td>
                </tr>

                <tr>
                    <td>BK003</td>
                    <td>HTML & CSS Guide</td>
                    <td>2025-12-05</td>
                    <td>2025-12-12</td>
                    <td><button class="return-btn">Return</button></td>
                </tr>

            </tbody>
        </table>

    </div>

</div>

<!-- ✅ SCRIPT FOR SINGLE ACTIVE -->
<script>
    const menuLinks = document.querySelectorAll('.menu');

    menuLinks.forEach(link => {
        link.addEventListener('click', function () {
            menuLinks.forEach(item => item.classList.remove('active'));
            this.classList.add('active');
        });
    });
</script>

</body>
</html>
