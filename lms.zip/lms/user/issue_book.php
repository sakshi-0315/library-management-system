<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Issue Book</title>

     <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4ff;
        }

        .container {
            display: flex;
            width: 100%;
            height: 100vh;
        }

    .topbar {
    background: linear-gradient(90deg, #023c6fff, #2e5c98ff) !important;
    padding: 15px 25px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-radius: 10px;
    margin-bottom: 20px;
    color: #ffffff !important;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}



        /* LEFT SIDE */
        .left-box {
    width: 38%;
    background: linear-gradient(135deg, #005a01ff, #81b83eff); /* gradient background */
    padding: 40px;
    color: black;
    display: flex;
    flex-direction: column;
    justify-content: center;
    border-radius: 0 20px 20px 0;
}


        .left-box h1 {
            font-size: 42px;
            margin: 0;
            font-weight: 900;
        }

        .left-box p {
            font-size: 18px;
            margin: 10px 0 20px 0;
        }

        .left-img {
            width: 250px;
            margin-top: 20px;
        }

        /* RIGHT SIDE */
        .right-box {
            width: 62%;
            background: white;
            padding: 60px;
        }

        .right-box h2 {
            margin: 0;
            font-size: 32px;
            font-weight: 700;
        }

        .right-box p {
            color: #555;
            margin-bottom: 25px;
        }

        /* FORM DESIGN */
        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .submit-btn {
            width: 100%;
            padding: 15px;
            background: #81b83eff;
            border: none;
            font-size: 18px;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
        }

        .submit-btn:hover {
            background: #81b83eff;
        }
    </style>
    <style>
/* ===== PAGE ===== */
body {
    font-family: Arial, sans-serif;
    background: #f4f6f8;
    margin: 0;
    padding: 30px;
}

/* ===== TABLE CONTAINER ===== */
.table-container {
    background: #ffffff;
    padding: 25px;
    border-radius: 14px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.12);
    max-width: 1000px;
    margin: auto;
}

/* ===== TABLE TITLE ===== */
.table-container h2 {
    margin-bottom: 20px;
    font-size: 24px;
    font-weight: 700;
    color: #023c6f;
}

/* ===== TABLE ===== */
table {
    width: 100%;
    border-collapse: collapse;
    font-size: 16px;
}

/* ===== HEADER ===== */
thead {
    background: linear-gradient(90deg, #023c6f, #2e5c98);
}

thead th {
    padding: 14px;
    text-align: left;
    color: #ffffff;
    font-weight: 600;
    letter-spacing: 0.5px;
}

/* ===== BODY ROWS ===== */
tbody tr {
    border-bottom: 1px solid #e0e0e0;
    transition: background 0.2s ease;
}

tbody tr:hover {
    background: #f1f7ff;
}

/* ===== CELLS ===== */
td {
    padding: 14px;
    color: #333;
}

/* ===== ROUND CORNERS ===== */
thead th:first-child {
    border-top-left-radius: 10px;
}

thead th:last-child {
    border-top-right-radius: 10px;
}

/* ===== RESPONSIVE ===== */
@media (max-width: 768px) {
    table {
        font-size: 14px;
    }
}
</style>

<link rel="stylesheet" href="style.css">
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>USER</h2>
    <a href="dashboard.php" class="menu">Dashboard</a>
    <a href="all_books.php" class="menu">All Books</a>
    <!-- <a href="#">Add Book</a> -->
    <a href="issue_book.php" class="menu active">Issue Book</a>
    <a href="return_book.php" class="menu">Return Book</a>
    <a href="history_book.php" class="menu">History</a>
    <a href="#" class="logout">Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">
    <div class="topbar">
        <h1>Issue Book</h1>
    </div>



    <!-- ISSUE BOOK FORM -->
    <div class="container">

    <!-- LEFT SIDE -->
    <div class="left-box">
        <h1>ISSUE BOOK</h1>
        <p>Simple & Fast Book Issuing System</p>
    

        <img src="https://cdn-icons-png.flaticon.com/512/1048/1048953.png" class="left-img">
    </div>

    <!-- RIGHT SIDE FORM -->
    <div class="right-box">
        <h2>Create Issue Record</h2>
        <p>Enter book and user details below</p>

        <form>

            <div class="form-group">
                <label>Book ID</label>
                <input type="text" placeholder="Enter Book ID">
            </div>

            <div class="form-group">
                <label>Book Name</label>
                <input type="text" placeholder="Enter Book Name">
            </div>

            <div class="form-group">
                <label>User ID</label>
                <input type="text" placeholder="Enter User ID">
            </div>

            <div class="form-group">
                <label>Issue Date</label>
                <input type="date">
            </div>

            <div class="form-group">
                <label>Return Date</label>
                <input type="date">
            </div>

            <button class="submit-btn">Issue Book</button>
        </form>
    </div>

</div>

<!-- ✅ SCRIPT FOR SINGLE ACTIVE -->
<script>
    const menuLinks = document.querySelectorAll('.menu');

    menuLinks.forEach(link => {
        link.addEventListener('click', function () {
            menuLinks.forEach(item => item.classList.remove('active'));
            this.classList.add('active');
        });
    });
</script>

</br>
</br>
</br>
</br>
    <!-- ISSUED BOOK TABLE -->
    <div class="table-container">
    <h2>Issued Books Table</h2>
    <table cellpadding="10" border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Book Name</th>
                <th>Book Type</th>
                <th>Issue Date</th>
                <th>Return Date</th>
            </tr>
        </thead>

        <tbody>
            <tr>
                <td>1</td>
                <td>Java Programming</td>
                <td>News Paper</td>
                <td>12-11-2025</td>
                <td>18-12-2025</td>
            </tr>

            <tr>
                <td>2</td>
                <td>Database Systems</td>
                <td>IT Book</td>
                <td>10-12-2025</td>
                <td>17-12-2025</td>
            </tr>
        </tbody>
    </table>
</div>


</div>

</body>
</html>
