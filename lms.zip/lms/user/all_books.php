<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>All Books</title>

<style>
/* ========= GLOBAL ========= */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6fb;
}

/* ========= SIDEBAR ========= */
.sidebar {
    width: 230px;
    height: 100vh;
    background: #1e252b;
    position: fixed;
    color: white;
    left: 0;
    top: 0;
    padding-top: 20px;
}

.sidebar h2 {
    text-align: center;
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    padding: 12px 20px;
    color: #dcdcdc;
    text-decoration: none;
    font-size: 16px;
}

.sidebar a:hover {
    background: #2c333a;
}

.sidebar a.active {
    background: #2c333a;
    border-left: 4px solid #00a8ff;
}

.sidebar .logout {
    background: #d61347;
    color: #fff;
    margin-top: 30px;
}

/* ========= MAIN ========= */
.main {
    margin-left: 250px;
    padding: 30px;
}

/* ========= TOP BAR ========= */
.topbar {
    background: linear-gradient(90deg, #023c6fff, #2e5c98ff) !important;
    padding: 22px 25px;
    border-radius: 14px;
    margin-bottom: 25px;
    box-shadow: 0 6px 16px rgba(0,0,0,0.15);
}

.topbar .title {
    font-size: 28px;
    font-weight: bold;
    color: #ffffff;
}

.topbar .subtitle {
    color: #dbe7ff;
    margin-top: 6px;
    font-size: 15px;
}

/* ========= FILTER ========= */
.filter-box {
    background: #ffffff;
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}

.filter-box label {
    display: block;
    margin-bottom: 6px;
}

.filter-box select {
    width: 100%;
    padding: 10px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

/* ========= SEARCH ========= */
.search-container {
    margin-bottom: 20px;
    display: flex;
    justify-content: flex-end;
}

.search-container input {
    width: 260px;
    padding: 10px 14px;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 15px;
}

/* ========= BOOK GRID ========= */
.grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
    gap: 20px;
}

/* ========= BOOK CARD ========= */
.book-card {
    background: #fff;
    padding: 20px;
    border-radius: 14px;
    text-align: center;
    box-shadow: 0 6px 14px rgba(0,0,0,0.08);
    transition: 0.3s ease;
}

.book-card:hover {
    transform: translateY(-5px);
}

.book-card img {
    width: 70px;
    margin-bottom: 10px;
}

.book-card h3 {
    font-size: 18px;
    margin: 10px 0;
}

.book-card p {
    color: #666;
    font-size: 14px;
}

/* ========= ISSUE BUTTON ========= */
.issue-btn {
    margin-top: 12px;
    padding: 9px 18px;
    background: #4f46e5;
    color: #fff;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

.issue-btn:hover {
    background: #3730a3;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>USER</h2>
    <a href="dashboard.php" class="menu">Dashboard</a>
    <a href="all_books.php" class="menu active">All Books</a>
    <!-- <a href="#">Add Book</a> -->
    <a href="issue_book.php" class="menu">Issue Book</a>
    <a href="return_book.php" class="menu">Return Book</a>
    <a href="history_book.php" class="menu">History</a>
    <a href="#" class="logout">Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">

    <!-- TOP BAR -->
    <div class="topbar">
        <div class="title">All Books</div>
        <div class="subtitle">Browse all available book categories</div>
    </div>

    <!-- FILTERS -->
    <div class="filter-box">
        <div class="row">
            <label>News Paper</label>
            <select>
                <option>All</option>
                <option>English</option>
                <option>Hindi</option>
                <option>Gujarati</option>
            </select>
            <br><br>
            <label>Books</label>
            <select>
                <option>All</option>
                <option>Java</option>
                <option>Python</option>
                <option>PHP</option>
            </select>
        </div>
    </div>

    <!-- SEARCH -->
    <div class="search-container">
        <input type="text" placeholder="Search books...">
    </div>


    <div class="grid">

        <div class="book-card">
            <img src="https://cdn-icons-png.flaticon.com/512/29/29302.png">
            <h3>Java Programming</h3>
            <p>Category: Programming</p>
            <button class="issue-btn">Issue</button>
        </div>

        <div class="book-card">
            <img src="https://cdn-icons-png.flaticon.com/512/942/942748.png">
            <h3>Database Systems</h3>
            <p>Category: Database</p>
            <button class="issue-btn">Issue</button>
        </div>

        <div class="book-card">
            <img src="https://cdn-icons-png.flaticon.com/512/1828/1828961.png">
            <h3>Python Basics</h3>
            <p>Category: Programming</p>
            <button class="issue-btn">Issue</button>
        </div>

        <div class="book-card">
            <img src="https://cdn-icons-png.flaticon.com/512/1157/1157109.png">
            <h3>HTML & CSS</h3>
            <p>Category: Web Design</p>
            <button class="issue-btn">Issue</button>
        </div>

        <div class="book-card">
            <img src="https://cdn-icons-png.flaticon.com/512/2305/2305904.png">
            <h3>C++ Guide</h3>
            <p>Category: Programming</p>
            <button class="issue-btn">Issue</button>
        </div>

        <div class="book-card">
            <img src="https://cdn-icons-png.flaticon.com/512/2345/2345876.png">
            <h3>Networking Basics</h3>
            <p>Category: Networking</p>
            <button class="issue-btn">Issue</button>
        </div>

        <div class="book-card">
            <img src="https://cdn-icons-png.flaticon.com/512/860/860798.png">
            <h3>All Books</h3>
            <p>Category: ALL</p>
            <button class="issue-btn">Issue</button>
        </div>

    </div>*\
</div>

<!-- ✅ SCRIPT FOR SINGLE ACTIVE -->
<script>
    const menuLinks = document.querySelectorAll('.menu');

    menuLinks.forEach(link => {
        link.addEventListener('click', function () {
            menuLinks.forEach(item => item.classList.remove('active'));
            this.classList.add('active');
        });
    });
</script>

</body>
</html>
